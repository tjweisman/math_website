$(window).on("load", function() {
	setPageContent();
	$("a").click(function(event) {
		toggleEnabled();
	});
});

function setPageContent() {
	chrome.storage.local.get(['enabled'], function(result) {
		if(result['enabled']) {
			setEnabled();
		} else {
			setDisabled();
		}
	});
}

function setEnabled() {
	$("#toggle").text("Disable");
	$("#status").text("enabled");
}

function setDisabled() {
	$("#toggle").text("Enable");
	$("#status").text("disabled");
}

function disableExtension() {
	setDisabled();
	chrome.storage.local.set({"enabled": false}, function() {
		console.log("disabled");
	});
}
function enableExtension() {
	setEnabled();
	chrome.storage.local.set({"enabled": true}, function() {
		console.log("enabled");
	});
}

function toggleEnabled() {
	chrome.storage.local.get(['enabled'], function(result) {
		if(result['enabled']) {
			disableExtension();
		} else {
			enableExtension();
		}
	});
}
