chrome.management.onInstalled.addListener(function(info) {
	chrome.storage.local.set({"enabled": true}, function() {
		console.log("enabled");
	});
});

chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
    if (request.message === "activate_icon") {
        chrome.pageAction.show(sender.tab.id);
    }
});