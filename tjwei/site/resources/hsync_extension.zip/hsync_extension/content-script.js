chrome.runtime.sendMessage({"message": "activate_icon"});

const SOCKETIO_URL = "https://hulu-sync.herokuapp.com/";
//const SOCKETIO_URL = "http://localhost:3000";

var currentState = {
	playback_position: "00:00",
	play_state: "UNKNOWN"
};

var syncEnabled = true;

function getSocket() {
	const connectionOptions = {
		"force new connection": true,
		"transports": ["websocket"]
	};

	var socket = io.connect(SOCKETIO_URL, connectionOptions);
	return socket;
}

function getState() {
	if($(".controls__playback-button--playing").length)
		return "PLAYING";

	if($(".controls__playback-button--paused").length)
		return "PAUSED";

	return "UNKNOWN";
}

function onPlayerPage() {
	return $(location).attr("href").match(/https:\/\/www\.hulu\.com\/watch\/.*/g);
}

/*
function setPlaybackPosition() {
	$(".controls__thumbnail-position").text("30:00");
	$(".controls__thumbnail-marker").click();
}
*/
function checkSyncEnabled() {
	chrome.storage.local.get(['enabled'], function(result) {
		if(result['enabled'] && onPlayerPage()) {
			syncEnabled = true;
			if(socket.disconnected) {
				socket.connect();
			}
		} else {
			syncEnabled = false;
			if(socket.connected) {
				socket.disconnect();
			}
		}
	});
}
function updateLocalState() {
	currentState["playback_position"] = getPlaybackPosition();
	currentState["play_state"] = getState();
}

function update() {
	checkSyncEnabled();
	waitForStateChange(2500).then(function() {
		sendUpdate(currentState);
	});
}

function getPlaybackPosition() {
	return $(".controls__time-elapsed").text();
}

function playVideo() {
	$(".controls__playback-button--paused").click();
}

function pauseVideo() {
	$(".controls__playback-button--playing").click();
}

function togglePlaying() {
	console
	if(currentState["play_state"] == "PLAYING") {
		pauseVideo();
	} else if(currentState["play_state"] == "PAUSED") {
		playVideo();
	}
}

function sendUpdate(videoState) {
	if(syncEnabled)
	{
		socket.emit("state update", {	
				"state": videoState,
				"time": new Date()
			});
	}
}

function receiveUpdate(videoState, updateTime) {
	console.log("update received");
	if(syncEnabled) {
		updateLocalState();
		if(currentState["play_state"] != videoState["play_state"]) {
			togglePlaying();
		}
	}
	
}

function mouseupListener(event) {
	console.log("mouseup");
	update();
}

function keyupListener(event) {
	update();
}

function waitForStateChange(maxTimeout) {
	let promise = delayUntil(function() {
		currentState["playback_position"] = getPlaybackPosition();
		if(getState() != currentState["play_state"]) {
			currentState["play_state"] = getState();
			return true;
		}
		return false;
	})();
	return promise;
}

// shamelessly stolen from netflix party

// returns an action which delays for some time
var delay = function(milliseconds) {
  return function(result) {
    return new Promise(function(resolve, reject) {
      setTimeout(function() {
        resolve(result);
      }, milliseconds);
    });
  };
};

// returns an action which waits until the condition thunk returns true,
// rejecting if maxDelay time is exceeded
var delayUntil = function(condition, maxDelay) {
  return function(result) {
    var delayStep = 250;
    var startTime = (new Date()).getTime();
    var checkForCondition = function() {
      if (condition()) {
        return Promise.resolve(result);
      }
      if (maxDelay !== null && (new Date()).getTime() - startTime > maxDelay) {
        return Promise.reject(Error('delayUntil timed out'));
      }
      return delay(delayStep)().then(checkForCondition);
    };
    return checkForCondition();
  };
};

var socket = getSocket();
socket.on("state update", function(state) {
	receiveUpdate(state["state"], state["time"]);
});

$(window).mouseup(mouseupListener);
$(window).keyup(keyupListener);
window.setInterval(update, 3000);